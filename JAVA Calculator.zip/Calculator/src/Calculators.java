import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import javax.swing.JMenuItem;

public class Calculators extends Convert{

	private JFrame frmCalculator;
	private JTextField textField;
	
	double firstnum;
	double secondnum;
	double N;
	double results;
	double results1;
	String operations;
	String answer;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Calculators window = new Calculators();
					window.frmCalculator.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public Calculators() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmCalculator = new JFrame();
		frmCalculator.setTitle("Calculator");
		frmCalculator.setBounds(100, 100, 275, 390);
		frmCalculator.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmCalculator.getContentPane().setLayout(null);
		

		JMenuBar menuBar = new JMenuBar();
		menuBar.setBounds(0, 0, 130, 32);
		frmCalculator.getContentPane().add(menuBar);
		
		JMenu mnFile = new JMenu("File");
		menuBar.add(mnFile);
		
		JMenuItem mntmStandardCalculator = new JMenuItem("Standard Calculator");
		mntmStandardCalculator.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				frmCalculator.setTitle("Calculator");
				frmCalculator.setBounds(100, 100, 275, 390);
				
				textField = new JTextField();
				textField.setHorizontalAlignment(SwingConstants.RIGHT);
				textField.setBounds(10, 43, 240, 39);
				frmCalculator.getContentPane().add(textField);
				textField.setColumns(10);
		//////////////////////////ROW1////////////////////////////////		
				JButton btnclear = new JButton("c");
				btnclear.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						textField.setText(null);
					} 
				});
				btnclear.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btnclear.setBounds(10, 84, 50, 50);
				frmCalculator.getContentPane().add(btnclear);
				
				JButton btnbackspace = new JButton("\u2190");
				btnbackspace.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						String backspace=null;
						if(textField.getText().length()>0) {
						StringBuilder strB = new StringBuilder(textField.getText());
						strB.deleteCharAt(textField.getText().length() - 1);
						backspace = strB.toString();
						textField.setText(backspace);
						}
					}
				});
				btnbackspace.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btnbackspace.setBounds(70, 84, 50, 50);
				frmCalculator.getContentPane().add(btnbackspace);
				///////////////////////////// Row2///////////////////////
				
				JButton btn7 = new JButton("7");
				btn7.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						
						String EnterNumber = textField.getText()+btn7.getText();
						textField.setText(EnterNumber );
						
					}
				});
				btn7.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn7.setBounds(10, 136, 50, 50);
				frmCalculator.getContentPane().add(btn7);
				
				JButton btn8 = new JButton("8");
				btn8.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						
						String EnterNumber = textField.getText()+btn8.getText();
						textField.setText(EnterNumber );
						
					}
				});
				btn8.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn8.setBounds(70, 136, 50, 50);
				frmCalculator.getContentPane().add(btn8);
				
				JButton btn9 = new JButton("9");
				btn9.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						
						String EnterNumber = textField.getText()+btn9.getText();
						textField.setText(EnterNumber );
						
					}
				});
				btn9.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn9.setBounds(140, 136, 50, 50);
				frmCalculator.getContentPane().add(btn9);
				
				JButton btndiv = new JButton("/");
				btndiv.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						firstnum=Double.parseDouble(textField.getText());
						textField.setText("");
						operations = "/";
					}
				});
				btndiv.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btndiv.setBounds(140, 84, 50, 50);
				frmCalculator.getContentPane().add(btndiv);
				
				//////////////////////////////////row3/////////////////////////////
				
				JButton btn4 = new JButton("4");
				btn4.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String EnterNumber = textField.getText()+btn4.getText();
						textField.setText(EnterNumber );
					}
				});
				btn4.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn4.setBounds(10, 186, 50, 50);
				frmCalculator.getContentPane().add(btn4);
				
				
				JButton btn5 = new JButton("5");
				btn5.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String EnterNumber = textField.getText()+btn5.getText();
						textField.setText(EnterNumber );
					}
				});
				btn5.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn5.setBounds(70, 186, 50, 50);
				frmCalculator.getContentPane().add(btn5);
				
				
				JButton btn6 = new JButton("6");
				btn6.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String EnterNumber = textField.getText()+btn6.getText();
						textField.setText(EnterNumber );
					}
				});
				btn6.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn6.setBounds(140, 186, 50, 50);
				frmCalculator.getContentPane().add(btn6);
				
				JButton btnmulty = new JButton("*");
				btnmulty.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						firstnum=Double.parseDouble(textField.getText());
						textField.setText("");
						operations = "*";
					}
				});
				btnmulty.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btnmulty.setBounds(198, 84, 50, 50);
				frmCalculator.getContentPane().add(btnmulty);
				
				//////////////////////row4//////////////////////////
				JButton btn1 = new JButton("1");
				btn1.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String EnterNumber = textField.getText()+btn1.getText();
						textField.setText(EnterNumber );
					}
				});
				btn1.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn1.setBounds(10, 237, 50, 50);
				frmCalculator.getContentPane().add(btn1);
				
				JButton btn2 = new JButton("2");
				btn2.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String EnterNumber = textField.getText()+btn2.getText();
						textField.setText(EnterNumber );
					}
				});
				btn2.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn2.setBounds(70, 237, 50, 50);
				frmCalculator.getContentPane().add(btn2);
				
				JButton btn3 = new JButton("3");
				btn3.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String EnterNumber = textField.getText()+btn3.getText();
						textField.setText(EnterNumber );
					}
				});
				btn3.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn3.setBounds(140, 237, 50, 50);
				frmCalculator.getContentPane().add(btn3);
				
				JButton btnsub = new JButton("-");
				btnsub.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
							
							firstnum=Double.parseDouble(textField.getText());
							textField.setText("");
							operations = "-";

					}
				});
				btnsub.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btnsub.setBounds(200, 136, 50, 50);
				frmCalculator.getContentPane().add(btnsub);
				
				////////////////////////row 5 ////////////////////////
				
				JButton btn0 = new JButton("0");
				btn0.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						String EnterNumber = textField.getText()+btn0.getText();
						textField.setText(EnterNumber );
					}
				});
				btn0.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btn0.setBounds(10, 290, 110, 50);
				frmCalculator.getContentPane().add(btn0);
				

				

				
				JButton btndot = new JButton(".");
				btndot.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btndot.setBounds(140, 290, 50, 50);
				frmCalculator.getContentPane().add(btndot);
				


				

				

				
				JButton btnsum = new JButton("+");
				btnsum.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						firstnum=Double.parseDouble(textField.getText());
						textField.setText("");
						operations = "+";
					}
				});
				btnsum.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btnsum.setBounds(200, 186, 50, 50);
				frmCalculator.getContentPane().add(btnsum);
				
				JButton btneq = new JButton("=");
				btneq.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent arg0) {
						
						
						String answer;
						secondnum =Double.parseDouble(textField.getText());
						if(operations == "+")
						{
							results = firstnum + secondnum;
							answer = String.format("%.2f",results);
							textField.setText(answer);
						}
						else if (operations == "-")
						{
							results = firstnum - secondnum;
							answer = String.format("%.2f",results);
							textField.setText(answer);
						}
						else if (operations == "*")
						{
							results = firstnum * secondnum;
							answer = String.format("%.2f",results);
							textField.setText(answer);
						}
						else if (operations == "/")
						{
							results = firstnum / secondnum;
							answer = String.format("%.2f",results);
							textField.setText(answer);
						}
						
					}
				});
				btneq.setFont(new Font("Franklin Gothic Demi", Font.BOLD, 12));
				btneq.setBounds(200, 237, 50, 101);
				frmCalculator.getContentPane().add(btneq);
				
			}
		});
		mnFile.add(mntmStandardCalculator);
		
		JMenuItem mntmExit = new JMenuItem("EXIT");
		mntmExit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				System.exit(0);
			}
		});
		
		JMenu mnConvertion = new JMenu("Convertion");
		mnFile.add(mnConvertion);
		
		JMenuItem mntmCelsuisToFahrenheit = new JMenuItem("Celsuis to Fahrenheit");
		mntmCelsuisToFahrenheit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				
				double fahrenheit;
				double celcuis;
				
				frmCalculator.setTitle("Celuis to Farenheit");
				frmCalculator.setBounds(100, 100, 311, 137);
				
				textField = new JTextField();
				textField.setHorizontalAlignment(SwingConstants.RIGHT);
				textField.setBounds(10, 11, 275, 31);
				frmCalculator.getContentPane().add(textField);
				textField.setColumns(10);
				
				JButton btnNewButton = new JButton("Convert");
				btnNewButton.setBounds(75, 52, 118, 35);
				frmCalculator.getContentPane().add(btnNewButton);
				
			}
		});
		mnConvertion.add(mntmCelsuisToFahrenheit);
		
		JMenuItem mntmFarenheitToCelsuis = new JMenuItem("Farenheit to Celsuis");
		mnConvertion.add(mntmFarenheitToCelsuis);
		mnFile.add(mntmExit);
		frmCalculator.getContentPane().setLayout(null);
		
		
		

		

	}
}
